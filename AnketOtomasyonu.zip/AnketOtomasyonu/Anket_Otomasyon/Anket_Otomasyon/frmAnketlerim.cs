﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Anket_Otomasyon
{
    public partial class frmAnketlerim : Form
    {
        public frmAnketlerim()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=LAPTOP-2BUCSTS1;Initial Catalog=ANKETDB;Integrated Security=True");
        SqlCommand komut;
        int id = 0;
        private void tmrTarihSaat_Tick(object sender, EventArgs e)
        {
            lblTarih.Text = DateTime.Now.ToLongDateString();
            lblSaat.Text = DateTime.Now.ToLongTimeString();
        }

        private void frmAnketlerim_Load(object sender, EventArgs e)
        {
            tmrTarihSaat.Start();
            verileriGoster();
        }

        private void btnGeri_Click(object sender, EventArgs e)
        {
            tmrTarihSaat.Start();
            frmAnketOlustur fr = (frmAnketOlustur)Application.OpenForms["frmAnketOlustur"];
            this.Visible = false;
            fr.Refresh();
            fr.Visible = true;
        }
        private void verileriGoster()
        {
            listAnketler.Items.Clear();
            baglanti.Open();
            SqlCommand komut = new SqlCommand(" select* from ANKETOLUSTUR", baglanti);
            SqlDataReader oku = komut.ExecuteReader();

            while (oku.Read())
            {
                ListViewItem ekle = new ListViewItem();
                ekle.Text = oku["ANKETOLUSTURID"].ToString();
                ekle.SubItems.Add(oku["KATEGORI"].ToString());
                ekle.SubItems.Add(oku["ANKETADI"].ToString());
                ekle.SubItems.Add(oku["SORU1"].ToString());
                ekle.SubItems.Add(oku["SORU2"].ToString());
                ekle.SubItems.Add(oku["SORU3"].ToString());
                ekle.SubItems.Add(oku["SORU4"].ToString());
                ekle.SubItems.Add(oku["SORU5"].ToString());
                listAnketler.Items.Add(ekle);
            }
            baglanti.Close();
        }
        private void btnGüncelle_Click(object sender, EventArgs e)
        {
            
            string sorgu = "update ANKETOLUSTUR set KATEGORI=@KATEGORI, ANKETADI=@ANKETADI, SORU1=@SORU1, SORU2=@SORU2, SORU3=@SORU3, SORU4=@SORU4, SORU5=@SORU5 where ANKETOLUSTURID=@ID";
            komut = new SqlCommand(sorgu, baglanti);
            komut.Parameters.AddWithValue("ID", id);
            komut.Parameters.AddWithValue("@KATEGORI", cmbKategori.Text);
            komut.Parameters.AddWithValue("@ANKETADI", txtAnketAd.Text);
            komut.Parameters.AddWithValue("@SORU1", txtSoruBir.Text);
            komut.Parameters.AddWithValue("@SORU2", txtSoruIki.Text);
            komut.Parameters.AddWithValue("@SORU3", txtSoruUc.Text);
            komut.Parameters.AddWithValue("@SORU4", txtSoruDort.Text);
            komut.Parameters.AddWithValue("@SORU5", txtSoruBes.Text);
            baglanti.Open();
            komut.ExecuteNonQuery();
            baglanti.Close();
            verileriGoster();
        }
        
        private void listAnketler_DoubleClick(object sender, EventArgs e)
        {
            id = int.Parse(listAnketler.SelectedItems[0].SubItems[0].Text);
            cmbKategori.Text= listAnketler.SelectedItems[0].SubItems[1].Text;
            txtAnketAd.Text = listAnketler.SelectedItems[0].SubItems[2].Text;
            txtSoruBir.Text = listAnketler.SelectedItems[0].SubItems[3].Text;
            txtSoruIki.Text = listAnketler.SelectedItems[0].SubItems[4].Text;
            txtSoruUc.Text = listAnketler.SelectedItems[0].SubItems[5].Text;
            txtSoruDort.Text = listAnketler.SelectedItems[0].SubItems[6].Text;
            txtSoruBes.Text = listAnketler.SelectedItems[0].SubItems[7].Text;
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            string sorgu = "Delete From ANKETOLUSTUR Where ANKETOLUSTURID=@ANKETOLUSTURID";
            komut = new SqlCommand(sorgu, baglanti);
            id = int.Parse(listAnketler.SelectedItems[0].SubItems[0].Text);
            komut.Parameters.AddWithValue("@ANKETOLUSTURID", id);
            baglanti.Open();
            komut.ExecuteNonQuery();
            baglanti.Close();
            verileriGoster();
            cmbKategori.Text = "";
            txtAnketAd.Text = "";
            txtSoruBir.Text = "";
            txtSoruIki.Text = "";
            txtSoruUc.Text = "";
            txtSoruDort.Text = "";
            txtSoruBes.Text = "";

        }

        private void listAnketler_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
