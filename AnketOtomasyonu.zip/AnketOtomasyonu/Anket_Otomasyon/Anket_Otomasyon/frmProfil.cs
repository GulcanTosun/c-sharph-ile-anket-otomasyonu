﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Anket_Otomasyon
{
    public partial class frmProfil : Form
    {
        public frmProfil()
        {
            InitializeComponent();
        }

        private void tmrTarihSaat_Tick(object sender, EventArgs e)
        {
            lblTarih.Text = DateTime.Now.ToLongDateString();
            lblSaat.Text = DateTime.Now.ToLongTimeString();
        }
        private void frmProfil_Load(object sender, EventArgs e)
        {
            tmrTarihSaat.Start();
        }

        private void btnSpor_Click(object sender, EventArgs e)
        {
            frmSpor fr = new frmSpor();
            fr.Show();
        }

        private void btnMagazin_Click(object sender, EventArgs e)
        {

            frmMagazin fr = new frmMagazin();
            fr.Show();
        }

        private void btnYazılım_Click(object sender, EventArgs e)
        {
            FrmYazilim fr = new FrmYazilim();
            fr.Show();
        }

        private void btnEkonomi_Click(object sender, EventArgs e)
        {
            frmEkonomi fr = new frmEkonomi();
            fr.Show();
        }

        private void btnSiyasi_Click(object sender, EventArgs e)
        {
            frmSiyasics fr = new frmSiyasics();
            fr.Show();
        }

        private void btnSosyal_Click(object sender, EventArgs e)
        {
            frmSosyal fr = new frmSosyal();
            fr.Show();
        }

        private void btnProfilBilgileri_Click(object sender, EventArgs e)
        {
            frmProfilBilgileri fr = new frmProfilBilgileri();
            fr.Show();
        }

        private void btnAnketOluştur_Click(object sender, EventArgs e)
        {
            frmAnketOlustur fr = new frmAnketOlustur();
            fr.Show();
        }
    }
}
