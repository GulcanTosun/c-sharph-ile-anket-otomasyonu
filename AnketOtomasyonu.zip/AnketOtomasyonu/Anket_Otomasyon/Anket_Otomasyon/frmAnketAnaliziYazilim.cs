﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Anket_Otomasyon
{
    public partial class frmAnketAnaliziYazilim : Form
    {
        public frmAnketAnaliziYazilim()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=LAPTOP-2BUCSTS1;Initial Catalog=ANKETDB;Integrated Security=True");
        SqlCommand komut;
        int id = 0;
        private void frmAnketAnaliziYazilim_Load(object sender, EventArgs e)
        {
            verileriGoster();
        }
        private void verileriGoster()
        {
            listAnketanalizi.Items.Clear();
            baglanti.Open();
            SqlCommand komut = new SqlCommand(" select* from YAZILIM", baglanti);
            SqlDataReader oku = komut.ExecuteReader();

            while (oku.Read())
            {
                ListViewItem ekle = new ListViewItem();
                ekle.Text = oku["YAZILIMID"].ToString();
                ekle.SubItems.Add(oku["ANKETADI"].ToString());
                ekle.SubItems.Add(oku["SORU1"].ToString());
                ekle.SubItems.Add(oku["SORU2"].ToString());
                ekle.SubItems.Add(oku["SORU3"].ToString());
                ekle.SubItems.Add(oku["SORU4"].ToString());
                listAnketanalizi.Items.Add(ekle);
            }
            baglanti.Close();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            string sorgu = "Delete From YAZILIM Where YAZILIMID=@YAZILIMID";
            komut = new SqlCommand(sorgu, baglanti);
            id = int.Parse(listAnketanalizi.SelectedItems[0].SubItems[0].Text);
            komut.Parameters.AddWithValue("@YAZILIMID", id);
            baglanti.Open();
            komut.ExecuteNonQuery();
            baglanti.Close();
            verileriGoster();
        }

        private void listAnketanalizi_DoubleClick(object sender, EventArgs e)
        {
            id = int.Parse(listAnketanalizi.SelectedItems[0].SubItems[0].Text);
        }
    }
}
