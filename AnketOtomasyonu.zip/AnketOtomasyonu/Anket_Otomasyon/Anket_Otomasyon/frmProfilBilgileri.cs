﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;


namespace Anket_Otomasyon
{
    public partial class frmProfilBilgileri : Form
    {
        public frmProfilBilgileri()
        {
            InitializeComponent();
        }
        private void tmrTarihSaat_Tick(object sender, EventArgs e)
        {
            lblTarih.Text = DateTime.Now.ToLongDateString();
            lblSaat.Text = DateTime.Now.ToLongTimeString();
        }

        private void btnGeri_Click(object sender, EventArgs e)
        {
            frmProfil fr = (frmProfil)Application.OpenForms["frmProfil"];
            this.Visible = false;
            fr.Refresh();
            fr.Visible = true; 
        }

        private void frmProfilBilgileri_Load(object sender, EventArgs e)
        {
            tmrTarihSaat.Start();
        }

        private void btnGüncelle_Click(object sender, EventArgs e)
        {

        }
    }
}
