﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Anket_Otomasyon
{
    public partial class frmGiris : Form
    {
        public frmGiris()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=LAPTOP-2BUCSTS1;Initial Catalog=ANKETDB;Integrated Security=True"); // globele yazılmasının sebebi her yerden erişim sağlanabilmesi için
        private void btnNext_Click(object sender, EventArgs e)
        {
            baglanti.Open();// bağlantı pasif durumda olduğu için burada açıyoruz
            SqlCommand komut = new SqlCommand("insert into KULLANICI(ADI,SOYADI,EPOSTA,YETKIID) values('" + txtAd.Text + "','" + TxtSad.Text + "','" + txtMail.Text+ "','" + 2 +"')", baglanti); // textboxlara gelen değerli veri tabanına atıyoruz.
            komut.ExecuteNonQuery();
            baglanti.Close();
            frmAnaSayfa fr = new frmAnaSayfa();
            fr.Show();
            this.Hide();

        }
    }
}
