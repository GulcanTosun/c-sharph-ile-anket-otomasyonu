﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Anket_Otomasyon
{
    public partial class frmSosyal : Form
    {
        public frmSosyal()
        {
            InitializeComponent();
        }
        SqlCommand komut;
        SqlConnection baglanti = new SqlConnection("Data Source=LAPTOP-2BUCSTS1;Initial Catalog=ANKETDB;Integrated Security=True");
        private void frmSosyal_Load(object sender, EventArgs e)
        {
        }

        private void btnAnket1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("insert into SOSYAL(ANKETADI,SORU1,SORU2,SORU3,SORU4) values('" + lblSosyal.Text + "','" + comSoru1.Text + "','" + ComSoru2.Text + "','" + comSoru3.Text + "','" + comSoru3.Text + "')", baglanti);
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Anketiniz başarılı bir şekilde kaydedilmiştir. Anket analizi kısmından ulaşabilirsiniz.", "ANKET KAYDEDİLDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            comSoru1.Text = "";
            ComSoru2.Text = "";
            comSoru3.Text = "";
            comSoru4.Text = "";
        }

        private void btnAnket2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("insert into SOSYAL(ANKETADI,SORU1,SORU2,SORU3,SORU4) values('" + lblSinema.Text + "','" + comA2Soru1.Text + "','" + comA2Soru2.Text + "','" + comA2Soru3.Text + "','" + comA2Soru4.Text + "')", baglanti);
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Anketiniz başarılı bir şekilde kaydedilmiştir. Anket analizi kısmından ulaşabilirsiniz.", "ANKET KAYDEDİLDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            comA2Soru1.Text = "";
            comA2Soru2.Text = "";
            comA2Soru3.Text = "";
            comA2Soru4.Text = "";
        }

        private void btnAnket3_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("insert into SOSYAL(ANKETADI,SORU1,SORU2,SORU3,SORU4) values('" +lblYuruyus.Text + "','" + comA3Soru1.Text + "','" + comA2Soru2.Text + "','" + comA3Soru3.Text + "','" + comA3Soru4.Text + "')", baglanti);
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Anketiniz başarılı bir şekilde kaydedilmiştir. Anket analizi kısmından ulaşabilirsiniz.", "ANKET KAYDEDİLDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            comA3Soru1.Text = "";
            comA3Soru2.Text = "";
            comA3Soru3.Text = "";
            comA3Soru4.Text = "";
        }
    }
}
