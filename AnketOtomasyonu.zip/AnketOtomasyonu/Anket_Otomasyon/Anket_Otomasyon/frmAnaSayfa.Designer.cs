﻿namespace Anket_Otomasyon
{
    partial class frmAnaSayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAnaSayfa));
            this.tmrSaatTarih = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnProfilOlustur = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSpor = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnMagazin = new System.Windows.Forms.Button();
            this.btnSosyal = new System.Windows.Forms.Button();
            this.btnSiyasi = new System.Windows.Forms.Button();
            this.btnEkonomi = new System.Windows.Forms.Button();
            this.btnYazılım = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnGirisYap = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblSaat = new System.Windows.Forms.Label();
            this.lblTarih = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tmrSaatTarih
            // 
            this.tmrSaatTarih.Tick += new System.EventHandler(this.tmrSaatTarih_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(277, 64);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(542, 96);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Hoşgeldiniz.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(6, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(277, 40);
            this.label2.TabIndex = 1;
            this.label2.Text = "Yan tarafta bulunan kategorilerden seçerek anket\r\ncevaplamaya başlayabilirsiniz.\r" +
    "\n";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(290, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(246, 76);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(283, 179);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(527, 66);
            this.label3.TabIndex = 25;
            this.label3.Text = resources.GetString("label3.Text");
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(283, 351);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(247, 57);
            this.label4.TabIndex = 27;
            this.label4.Text = "Soru ve görüşleriniz için lütfen\r\nAnketdunyası@gmail.com\r\nadresi ile iletişime ge" +
    "çiniz.\r\n";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(283, 422);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(183, 38);
            this.label5.TabIndex = 28;
            this.label5.Text = "Bizi tercih ettiğiniz için\r\nteşekkür ederiz.";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(536, 316);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(283, 174);
            this.pictureBox2.TabIndex = 26;
            this.pictureBox2.TabStop = false;
            // 
            // btnProfilOlustur
            // 
            this.btnProfilOlustur.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnProfilOlustur.BackgroundImage")));
            this.btnProfilOlustur.Location = new System.Drawing.Point(283, 257);
            this.btnProfilOlustur.Name = "btnProfilOlustur";
            this.btnProfilOlustur.Size = new System.Drawing.Size(536, 53);
            this.btnProfilOlustur.TabIndex = 24;
            this.btnProfilOlustur.Text = "Profil Oluştur";
            this.btnProfilOlustur.UseVisualStyleBackColor = true;
            this.btnProfilOlustur.Click += new System.EventHandler(this.btnProfilOlustur_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MidnightBlue;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnSpor);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnMagazin);
            this.panel1.Controls.Add(this.btnSosyal);
            this.panel1.Controls.Add(this.btnSiyasi);
            this.panel1.Controls.Add(this.btnEkonomi);
            this.panel1.Controls.Add(this.btnYazılım);
            this.panel1.Location = new System.Drawing.Point(26, 64);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(245, 426);
            this.panel1.TabIndex = 22;
            // 
            // btnSpor
            // 
            this.btnSpor.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSpor.BackgroundImage")));
            this.btnSpor.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSpor.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSpor.Location = new System.Drawing.Point(17, 114);
            this.btnSpor.Name = "btnSpor";
            this.btnSpor.Size = new System.Drawing.Size(102, 53);
            this.btnSpor.TabIndex = 17;
            this.btnSpor.Text = "Spor";
            this.btnSpor.UseVisualStyleBackColor = true;
            this.btnSpor.Click += new System.EventHandler(this.btnSpor_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(14, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 32);
            this.label1.TabIndex = 21;
            this.label1.Text = "Lütfen cevaplamak istediğiniz\r\nkategoriyi seçin.";
            // 
            // btnMagazin
            // 
            this.btnMagazin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMagazin.BackgroundImage")));
            this.btnMagazin.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnMagazin.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnMagazin.Location = new System.Drawing.Point(125, 114);
            this.btnMagazin.Name = "btnMagazin";
            this.btnMagazin.Size = new System.Drawing.Size(102, 53);
            this.btnMagazin.TabIndex = 16;
            this.btnMagazin.Text = "Magazin";
            this.btnMagazin.UseVisualStyleBackColor = true;
            this.btnMagazin.Click += new System.EventHandler(this.btnMagazin_Click);
            // 
            // btnSosyal
            // 
            this.btnSosyal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSosyal.BackgroundImage")));
            this.btnSosyal.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSosyal.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSosyal.Location = new System.Drawing.Point(125, 286);
            this.btnSosyal.Name = "btnSosyal";
            this.btnSosyal.Size = new System.Drawing.Size(102, 53);
            this.btnSosyal.TabIndex = 18;
            this.btnSosyal.Text = "Sosyal";
            this.btnSosyal.UseVisualStyleBackColor = true;
            this.btnSosyal.Click += new System.EventHandler(this.btnSosyal_Click);
            // 
            // btnSiyasi
            // 
            this.btnSiyasi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSiyasi.BackgroundImage")));
            this.btnSiyasi.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSiyasi.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSiyasi.Location = new System.Drawing.Point(17, 286);
            this.btnSiyasi.Name = "btnSiyasi";
            this.btnSiyasi.Size = new System.Drawing.Size(102, 53);
            this.btnSiyasi.TabIndex = 19;
            this.btnSiyasi.Text = "Siyasi";
            this.btnSiyasi.UseVisualStyleBackColor = true;
            this.btnSiyasi.Click += new System.EventHandler(this.btnSiyasi_Click);
            // 
            // btnEkonomi
            // 
            this.btnEkonomi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEkonomi.BackgroundImage")));
            this.btnEkonomi.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnEkonomi.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnEkonomi.Location = new System.Drawing.Point(125, 201);
            this.btnEkonomi.Name = "btnEkonomi";
            this.btnEkonomi.Size = new System.Drawing.Size(102, 53);
            this.btnEkonomi.TabIndex = 20;
            this.btnEkonomi.Text = "Ekonomi";
            this.btnEkonomi.UseVisualStyleBackColor = true;
            this.btnEkonomi.Click += new System.EventHandler(this.btnEkonomi_Click);
            // 
            // btnYazılım
            // 
            this.btnYazılım.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnYazılım.BackgroundImage")));
            this.btnYazılım.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnYazılım.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnYazılım.Location = new System.Drawing.Point(17, 201);
            this.btnYazılım.Name = "btnYazılım";
            this.btnYazılım.Size = new System.Drawing.Size(102, 53);
            this.btnYazılım.TabIndex = 15;
            this.btnYazılım.Text = "Yazılım";
            this.btnYazılım.UseVisualStyleBackColor = true;
            this.btnYazılım.Click += new System.EventHandler(this.btnYazılım_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.MenuBar;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btnGirisYap);
            this.panel2.Controls.Add(this.btnCikis);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(26, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(793, 46);
            this.panel2.TabIndex = 3;
            // 
            // btnGirisYap
            // 
            this.btnGirisYap.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGirisYap.BackgroundImage")));
            this.btnGirisYap.Location = new System.Drawing.Point(92, 3);
            this.btnGirisYap.Name = "btnGirisYap";
            this.btnGirisYap.Size = new System.Drawing.Size(83, 38);
            this.btnGirisYap.TabIndex = 25;
            this.btnGirisYap.Text = "Giriş Yap";
            this.btnGirisYap.UseVisualStyleBackColor = true;
            this.btnGirisYap.Click += new System.EventHandler(this.btnGirisYap_Click);
            // 
            // btnCikis
            // 
            this.btnCikis.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCikis.BackgroundImage")));
            this.btnCikis.Location = new System.Drawing.Point(3, 3);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(83, 38);
            this.btnCikis.TabIndex = 24;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = true;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MidnightBlue;
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.Controls.Add(this.lblSaat);
            this.panel3.Controls.Add(this.lblTarih);
            this.panel3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel3.Location = new System.Drawing.Point(557, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(235, 45);
            this.panel3.TabIndex = 23;
            // 
            // lblSaat
            // 
            this.lblSaat.AutoSize = true;
            this.lblSaat.BackColor = System.Drawing.Color.Transparent;
            this.lblSaat.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblSaat.Location = new System.Drawing.Point(158, 16);
            this.lblSaat.Name = "lblSaat";
            this.lblSaat.Size = new System.Drawing.Size(33, 16);
            this.lblSaat.TabIndex = 18;
            this.lblSaat.Text = "saat";
            // 
            // lblTarih
            // 
            this.lblTarih.AutoSize = true;
            this.lblTarih.BackColor = System.Drawing.Color.Transparent;
            this.lblTarih.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblTarih.Location = new System.Drawing.Point(6, 16);
            this.lblTarih.Name = "lblTarih";
            this.lblTarih.Size = new System.Drawing.Size(32, 16);
            this.lblTarih.TabIndex = 17;
            this.lblTarih.Text = "tarih";
            // 
            // frmAnaSayfa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(841, 509);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnProfilOlustur);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAnaSayfa";
            this.Text = "Anket Dünyası";
            this.Load += new System.EventHandler(this.frmAnaSayfa_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer tmrSaatTarih;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblSaat;
        private System.Windows.Forms.Label lblTarih;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnEkonomi;
        private System.Windows.Forms.Button btnSiyasi;
        private System.Windows.Forms.Button btnSosyal;
        private System.Windows.Forms.Button btnSpor;
        private System.Windows.Forms.Button btnMagazin;
        private System.Windows.Forms.Button btnYazılım;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCikis;
        private System.Windows.Forms.Button btnProfilOlustur;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnGirisYap;
    }
}