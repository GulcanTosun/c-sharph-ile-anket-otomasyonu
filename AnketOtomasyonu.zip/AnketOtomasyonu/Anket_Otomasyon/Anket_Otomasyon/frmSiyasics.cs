﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Anket_Otomasyon
{
    public partial class frmSiyasics : Form
    {
        public frmSiyasics()
        {
            InitializeComponent();
        }
        SqlCommand komut;
        SqlConnection baglanti = new SqlConnection("Data Source=LAPTOP-2BUCSTS1;Initial Catalog=ANKETDB;Integrated Security=True");
        private void frmSiyasics_Load(object sender, EventArgs e)
        {
        }

        private void btnAnket1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("insert into SIYASET(ANKETADI,SORU1,SORU2,SORU3,SORU4) values('" + lblSiyasi.Text + "','" + comSoru1.Text + "','" + ComSoru2.Text + "','" + comSoru3.Text + "','" + comSoru3.Text + "')", baglanti);
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Anketiniz başarılı bir şekilde kaydedilmiştir. Anket analizi kısmından ulaşabilirsiniz.", "ANKET KAYDEDİLDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnAnket2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("insert into SIYASET(ANKETADI,SORU1,SORU2,SORU3,SORU4) values('" + lblAnayasa.Text + "','" + txtA2Soru1.Text + "','" + txtA2Soru2.Text + "','" + txtA2Soru3.Text + "','" + comA2Soru4.Text + "')", baglanti);
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Anketiniz başarılı bir şekilde kaydedilmiştir. Anket analizi kısmından ulaşabilirsiniz.", "ANKET KAYDEDİLDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnAnket3_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("insert into SIYASET(ANKETADI,SORU1,SORU2,SORU3,SORU4) values('" + lblKadınHakları.Text + "','" + txtA3Soru1.Text + "','" + comA3Soru2.Text + "','" + txtA3Soru3.Text + "','" + comA3Soru4.Text + "')", baglanti);
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Anketiniz başarılı bir şekilde kaydedilmiştir. Anket analizi kısmından ulaşabilirsiniz.", "ANKET KAYDEDİLDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnAnketAnalizi_Click(object sender, EventArgs e)
        {
            frmAnketAnalizSiyasi fr = new frmAnketAnalizSiyasi();
            fr.Show();
        }
    }
}
