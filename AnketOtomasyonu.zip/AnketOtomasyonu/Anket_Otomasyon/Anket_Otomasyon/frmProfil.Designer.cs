﻿namespace Anket_Otomasyon
{
    partial class frmProfil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProfil));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tmrTarihSaat = new System.Windows.Forms.Timer(this.components);
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnAnketOluştur = new System.Windows.Forms.Button();
            this.btnProfilBilgileri = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSpor = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnMagazin = new System.Windows.Forms.Button();
            this.btnSosyal = new System.Windows.Forms.Button();
            this.btnSiyasi = new System.Windows.Forms.Button();
            this.btnEkonomi = new System.Windows.Forms.Button();
            this.btnYazılım = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCikis = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblSaat = new System.Windows.Forms.Label();
            this.lblTarih = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(263, 64);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(542, 140);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Hoşgeldiniz.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(6, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(277, 40);
            this.label2.TabIndex = 1;
            this.label2.Text = "Yan tarafta bulunan kategorilerden seçerek anket\r\ncevaplamaya başlayabilirsiniz.\r" +
    "\n";
            // 
            // tmrTarihSaat
            // 
            this.tmrTarihSaat.Tick += new System.EventHandler(this.tmrTarihSaat_Tick);
            // 
            // panel4
            // 
            this.panel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel4.BackColor = System.Drawing.Color.AliceBlue;
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.Controls.Add(this.btnAnketOluştur);
            this.panel4.Controls.Add(this.btnProfilBilgileri);
            this.panel4.Location = new System.Drawing.Point(263, 210);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(542, 278);
            this.panel4.TabIndex = 2;
            // 
            // btnAnketOluştur
            // 
            this.btnAnketOluştur.BackColor = System.Drawing.Color.Gainsboro;
            this.btnAnketOluştur.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAnketOluştur.BackgroundImage")));
            this.btnAnketOluştur.Location = new System.Drawing.Point(21, 158);
            this.btnAnketOluştur.Name = "btnAnketOluştur";
            this.btnAnketOluştur.Size = new System.Drawing.Size(501, 53);
            this.btnAnketOluştur.TabIndex = 40;
            this.btnAnketOluştur.Text = "Anket Oluştur";
            this.btnAnketOluştur.UseVisualStyleBackColor = false;
            this.btnAnketOluştur.Click += new System.EventHandler(this.btnAnketOluştur_Click);
            // 
            // btnProfilBilgileri
            // 
            this.btnProfilBilgileri.BackColor = System.Drawing.Color.Gainsboro;
            this.btnProfilBilgileri.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnProfilBilgileri.BackgroundImage")));
            this.btnProfilBilgileri.Location = new System.Drawing.Point(21, 75);
            this.btnProfilBilgileri.Name = "btnProfilBilgileri";
            this.btnProfilBilgileri.Size = new System.Drawing.Size(501, 53);
            this.btnProfilBilgileri.TabIndex = 39;
            this.btnProfilBilgileri.Text = "Profil Bilgileri";
            this.btnProfilBilgileri.UseVisualStyleBackColor = false;
            this.btnProfilBilgileri.Click += new System.EventHandler(this.btnProfilBilgileri_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(290, 35);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(246, 92);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MidnightBlue;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnSpor);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnMagazin);
            this.panel1.Controls.Add(this.btnSosyal);
            this.panel1.Controls.Add(this.btnSiyasi);
            this.panel1.Controls.Add(this.btnEkonomi);
            this.panel1.Controls.Add(this.btnYazılım);
            this.panel1.Location = new System.Drawing.Point(12, 64);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(245, 426);
            this.panel1.TabIndex = 30;
            // 
            // btnSpor
            // 
            this.btnSpor.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSpor.BackgroundImage")));
            this.btnSpor.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSpor.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSpor.Location = new System.Drawing.Point(17, 114);
            this.btnSpor.Name = "btnSpor";
            this.btnSpor.Size = new System.Drawing.Size(102, 53);
            this.btnSpor.TabIndex = 17;
            this.btnSpor.Text = "Spor";
            this.btnSpor.UseVisualStyleBackColor = true;
            this.btnSpor.Click += new System.EventHandler(this.btnSpor_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(14, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 32);
            this.label1.TabIndex = 21;
            this.label1.Text = "Lütfen cevaplamak istediğiniz\r\nkategoriyi seçin.";
            // 
            // btnMagazin
            // 
            this.btnMagazin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMagazin.BackgroundImage")));
            this.btnMagazin.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnMagazin.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnMagazin.Location = new System.Drawing.Point(125, 114);
            this.btnMagazin.Name = "btnMagazin";
            this.btnMagazin.Size = new System.Drawing.Size(102, 53);
            this.btnMagazin.TabIndex = 16;
            this.btnMagazin.Text = "Magazin";
            this.btnMagazin.UseVisualStyleBackColor = true;
            this.btnMagazin.Click += new System.EventHandler(this.btnMagazin_Click);
            // 
            // btnSosyal
            // 
            this.btnSosyal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSosyal.BackgroundImage")));
            this.btnSosyal.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSosyal.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSosyal.Location = new System.Drawing.Point(125, 286);
            this.btnSosyal.Name = "btnSosyal";
            this.btnSosyal.Size = new System.Drawing.Size(102, 53);
            this.btnSosyal.TabIndex = 18;
            this.btnSosyal.Text = "Sosyal";
            this.btnSosyal.UseVisualStyleBackColor = true;
            this.btnSosyal.Click += new System.EventHandler(this.btnSosyal_Click);
            // 
            // btnSiyasi
            // 
            this.btnSiyasi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSiyasi.BackgroundImage")));
            this.btnSiyasi.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSiyasi.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSiyasi.Location = new System.Drawing.Point(17, 286);
            this.btnSiyasi.Name = "btnSiyasi";
            this.btnSiyasi.Size = new System.Drawing.Size(102, 53);
            this.btnSiyasi.TabIndex = 19;
            this.btnSiyasi.Text = "Siyasi";
            this.btnSiyasi.UseVisualStyleBackColor = true;
            this.btnSiyasi.Click += new System.EventHandler(this.btnSiyasi_Click);
            // 
            // btnEkonomi
            // 
            this.btnEkonomi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEkonomi.BackgroundImage")));
            this.btnEkonomi.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnEkonomi.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnEkonomi.Location = new System.Drawing.Point(125, 201);
            this.btnEkonomi.Name = "btnEkonomi";
            this.btnEkonomi.Size = new System.Drawing.Size(102, 53);
            this.btnEkonomi.TabIndex = 20;
            this.btnEkonomi.Text = "Ekonomi";
            this.btnEkonomi.UseVisualStyleBackColor = true;
            this.btnEkonomi.Click += new System.EventHandler(this.btnEkonomi_Click);
            // 
            // btnYazılım
            // 
            this.btnYazılım.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnYazılım.BackgroundImage")));
            this.btnYazılım.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnYazılım.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnYazılım.Location = new System.Drawing.Point(17, 201);
            this.btnYazılım.Name = "btnYazılım";
            this.btnYazılım.Size = new System.Drawing.Size(102, 53);
            this.btnYazılım.TabIndex = 15;
            this.btnYazılım.Text = "Yazılım";
            this.btnYazılım.UseVisualStyleBackColor = true;
            this.btnYazılım.Click += new System.EventHandler(this.btnYazılım_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.MenuBar;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btnCikis);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(793, 46);
            this.panel2.TabIndex = 29;
            // 
            // btnCikis
            // 
            this.btnCikis.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCikis.BackgroundImage")));
            this.btnCikis.Location = new System.Drawing.Point(3, 3);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(83, 38);
            this.btnCikis.TabIndex = 24;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MidnightBlue;
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.Controls.Add(this.lblSaat);
            this.panel3.Controls.Add(this.lblTarih);
            this.panel3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel3.Location = new System.Drawing.Point(557, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(235, 45);
            this.panel3.TabIndex = 23;
            // 
            // lblSaat
            // 
            this.lblSaat.AutoSize = true;
            this.lblSaat.BackColor = System.Drawing.Color.Transparent;
            this.lblSaat.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblSaat.Location = new System.Drawing.Point(164, 16);
            this.lblSaat.Name = "lblSaat";
            this.lblSaat.Size = new System.Drawing.Size(33, 16);
            this.lblSaat.TabIndex = 18;
            this.lblSaat.Text = "saat";
            // 
            // lblTarih
            // 
            this.lblTarih.AutoSize = true;
            this.lblTarih.BackColor = System.Drawing.Color.Transparent;
            this.lblTarih.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblTarih.Location = new System.Drawing.Point(6, 16);
            this.lblTarih.Name = "lblTarih";
            this.lblTarih.Size = new System.Drawing.Size(32, 16);
            this.lblTarih.TabIndex = 17;
            this.lblTarih.Text = "tarih";
            // 
            // frmProfil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(817, 500);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmProfil";
            this.Text = "Üye Profil";
            this.Load += new System.EventHandler(this.frmProfil_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSpor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnMagazin;
        private System.Windows.Forms.Button btnSosyal;
        private System.Windows.Forms.Button btnSiyasi;
        private System.Windows.Forms.Button btnEkonomi;
        private System.Windows.Forms.Button btnYazılım;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnCikis;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblSaat;
        private System.Windows.Forms.Label lblTarih;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnAnketOluştur;
        private System.Windows.Forms.Button btnProfilBilgileri;
        private System.Windows.Forms.Timer tmrTarihSaat;
    }
}