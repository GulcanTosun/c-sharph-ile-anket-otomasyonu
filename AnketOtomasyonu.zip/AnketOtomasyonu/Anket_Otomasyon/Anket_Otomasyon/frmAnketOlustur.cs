﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Anket_Otomasyon
{
    public partial class frmAnketOlustur : Form
    {
        public frmAnketOlustur()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=LAPTOP-2BUCSTS1;Initial Catalog=ANKETDB;Integrated Security=True");
        private void tmrTarihSaat_Tick(object sender, EventArgs e)
        {
            lblTarih.Text = DateTime.Now.ToLongDateString();
            lblSaat.Text = DateTime.Now.ToLongTimeString();
        }

        private void frmAnketOlustur_Load(object sender, EventArgs e)
        {
            tmrTarihSaat.Start();
        }

        private void btnGeri_Click(object sender, EventArgs e)
        {
            tmrTarihSaat.Start();
            frmProfil fr = (frmProfil)Application.OpenForms["frmProfil"];
            this.Visible = false;
            fr.Refresh();
            fr.Visible = true;
        }

        private void btnAnketlerim_Click(object sender, EventArgs e)
        {
            frmAnketlerim fr = new frmAnketlerim();
            fr.Show();
            this.Hide();    
        }

        private void btnAnketOlustur_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("insert into ANKETOLUSTUR(KATEGORI,ANKETADI,SORU1,SORU2,SORU3,SORU4,SORU5) values('" +cmbKategori.Text + "','" + txtAnketAd.Text + "','" + txtSoruBir.Text + "','" + txtSoruIki.Text + "','"+txtSoruUc.Text+"','"+txtSoruDort.Text+"','"+txtSoruBes.Text +"')", baglanti);
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Anketlerim kısmından erişim sağlayabilirsiniz.","ANKET OLUŞTURMA BAŞARILI",MessageBoxButtons.OK,MessageBoxIcon.Information);
            cmbKategori.Text = "";
            txtAnketAd.Text = "";
            txtSoruBir.Text = "";
            txtSoruIki.Text = "";
            txtSoruUc.Text = "";
            txtSoruDort.Text = "";
            txtSoruBes.Text = "";
        }
    }
}
