﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Anket_Otomasyon
{
    public partial class frmProfilOlustur : Form
    {
        public frmProfilOlustur()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=LAPTOP-2BUCSTS1;Initial Catalog=ANKETDB;Integrated Security=True"); // globele yazılmasının sebebi her yerden erişim sağlanabilmesi için
        private void frmProfilOlustur_Load(object sender, EventArgs e)
        {
            tmrTarihSaat.Start();
        }

        private void btnGeri_Click(object sender, EventArgs e)
        {
            frmAnaSayfa fr = (frmAnaSayfa)Application.OpenForms["frmAnaSayfa"];
            this.Visible = false;
            fr.Refresh();
            fr.Visible = true;
        }

        private void tmrTarihSaat_Tick(object sender, EventArgs e)
        {
            lblTarih.Text = DateTime.Now.ToLongDateString();
            lblSaat.Text = DateTime.Now.ToLongTimeString();
        }

        private void btnProfilOlustur_Click(object sender, EventArgs e)
        {
            baglanti.Open();// bağlantı pasif durumda olduğu için burada açıyoruz
            SqlCommand komut = new SqlCommand("insert into UYE(AD,SOYAD,EPOSTA,TEL,SİFRE.YETKIID) values('" + txtAd.Text + "','" + txtSad.Text + "','" + txtEposta.Text + "','" + txtTelefon.Text+"','"+txtSifre.Text+ "','"+1+"')", baglanti);
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Profil başarı ile oluşturuldu.");
            txtAd.Text = "";
            txtEposta.Text = "";
            txtSad.Text = "";
            txtSifre.Text = "";
            txtTelefon.Text = "";
         }
    }
}
