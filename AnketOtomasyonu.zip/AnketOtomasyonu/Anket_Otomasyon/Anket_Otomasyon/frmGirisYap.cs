﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;

namespace Anket_Otomasyon
{
    public partial class frmGirisYap : Form
    {
        public frmGirisYap()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=LAPTOP-2BUCSTS1;Initial Catalog=ANKETDB;Integrated Security=True");
            
        private void btnGirisYap_Click(object sender, EventArgs e)
        {
            try
            {  
                baglanti.Open(); 
                string sql = " select*from UYE where EPOSTA=@EPOSTA AND SİFRE=@SİFRE";
                SqlParameter prmt1 = new SqlParameter("EPOSTA",txtEposta.Text);
                SqlParameter prmt2 = new SqlParameter("SİFRE",TxtSifre.Text);
                SqlCommand komut = new SqlCommand(sql, baglanti);
                komut.Parameters.Add(prmt1);
                komut.Parameters.Add(prmt2);

                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(komut);
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    frmProfil fr = new frmProfil();
                    fr.Show();  
                    this.Hide();
                    fr.Enabled = true;

                }
                else
                {
                    frmProfil fr = new frmProfil();
                    fr.Enabled = false;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hatalı giriş,lütfen bilgilerinizi kontrol ederek tekrar deneyiniz.");
            }

        }
    }
}
