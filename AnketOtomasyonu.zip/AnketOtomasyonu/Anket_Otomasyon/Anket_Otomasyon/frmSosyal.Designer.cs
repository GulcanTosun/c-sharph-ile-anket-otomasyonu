﻿namespace Anket_Otomasyon
{
    partial class frmSosyal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSosyal));
            this.comA2Soru4 = new System.Windows.Forms.ComboBox();
            this.comA2Soru2 = new System.Windows.Forms.ComboBox();
            this.comA2Soru1 = new System.Windows.Forms.ComboBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.comA3Soru4 = new System.Windows.Forms.ComboBox();
            this.comA3Soru3 = new System.Windows.Forms.ComboBox();
            this.comA3Soru2 = new System.Windows.Forms.ComboBox();
            this.comA3Soru1 = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.btnAnket3 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lblYuruyus = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.comA2Soru3 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.comSoru4 = new System.Windows.Forms.ComboBox();
            this.comSoru3 = new System.Windows.Forms.ComboBox();
            this.ComSoru2 = new System.Windows.Forms.ComboBox();
            this.comSoru1 = new System.Windows.Forms.ComboBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.lblSosyal = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnAnket1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.btnAnket2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblSinema = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAnketAnalizi = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // comA2Soru4
            // 
            this.comA2Soru4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comA2Soru4.FormattingEnabled = true;
            this.comA2Soru4.Items.AddRange(new object[] {
            "Evet",
            "Hayır"});
            this.comA2Soru4.Location = new System.Drawing.Point(38, 385);
            this.comA2Soru4.Name = "comA2Soru4";
            this.comA2Soru4.Size = new System.Drawing.Size(395, 30);
            this.comA2Soru4.TabIndex = 82;
            // 
            // comA2Soru2
            // 
            this.comA2Soru2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comA2Soru2.FormattingEnabled = true;
            this.comA2Soru2.Items.AddRange(new object[] {
            "Evet",
            "Hayır"});
            this.comA2Soru2.Location = new System.Drawing.Point(38, 211);
            this.comA2Soru2.Name = "comA2Soru2";
            this.comA2Soru2.Size = new System.Drawing.Size(395, 30);
            this.comA2Soru2.TabIndex = 80;
            // 
            // comA2Soru1
            // 
            this.comA2Soru1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comA2Soru1.FormattingEnabled = true;
            this.comA2Soru1.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.comA2Soru1.Location = new System.Drawing.Point(38, 122);
            this.comA2Soru1.Name = "comA2Soru1";
            this.comA2Soru1.Size = new System.Drawing.Size(395, 30);
            this.comA2Soru1.TabIndex = 79;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.comA3Soru4);
            this.panel4.Controls.Add(this.comA3Soru3);
            this.panel4.Controls.Add(this.comA3Soru2);
            this.panel4.Controls.Add(this.comA3Soru1);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.btnAnket3);
            this.panel4.Controls.Add(this.pictureBox2);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.lblYuruyus);
            this.panel4.Controls.Add(this.label24);
            this.panel4.Controls.Add(this.label25);
            this.panel4.Controls.Add(this.label26);
            this.panel4.Controls.Add(this.label27);
            this.panel4.Location = new System.Drawing.Point(981, 99);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(472, 507);
            this.panel4.TabIndex = 86;
            // 
            // comA3Soru4
            // 
            this.comA3Soru4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comA3Soru4.FormattingEnabled = true;
            this.comA3Soru4.Items.AddRange(new object[] {
            "Evet",
            "Hayır"});
            this.comA3Soru4.Location = new System.Drawing.Point(53, 379);
            this.comA3Soru4.Name = "comA3Soru4";
            this.comA3Soru4.Size = new System.Drawing.Size(395, 30);
            this.comA3Soru4.TabIndex = 85;
            // 
            // comA3Soru3
            // 
            this.comA3Soru3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comA3Soru3.FormattingEnabled = true;
            this.comA3Soru3.Items.AddRange(new object[] {
            "Tek",
            "Arkadaşlarım ile",
            "Ailem ile ",
            "Evcil hayvanım ile "});
            this.comA3Soru3.Location = new System.Drawing.Point(53, 291);
            this.comA3Soru3.Name = "comA3Soru3";
            this.comA3Soru3.Size = new System.Drawing.Size(395, 30);
            this.comA3Soru3.TabIndex = 83;
            // 
            // comA3Soru2
            // 
            this.comA3Soru2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comA3Soru2.FormattingEnabled = true;
            this.comA3Soru2.Items.AddRange(new object[] {
            "Evet",
            "Hayır"});
            this.comA3Soru2.Location = new System.Drawing.Point(53, 211);
            this.comA3Soru2.Name = "comA3Soru2";
            this.comA3Soru2.Size = new System.Drawing.Size(395, 30);
            this.comA3Soru2.TabIndex = 84;
            // 
            // comA3Soru1
            // 
            this.comA3Soru1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comA3Soru1.FormattingEnabled = true;
            this.comA3Soru1.Items.AddRange(new object[] {
            "30 dk",
            "1 saat",
            "1,5 saat "});
            this.comA3Soru1.Location = new System.Drawing.Point(53, 122);
            this.comA3Soru1.Name = "comA3Soru1";
            this.comA3Soru1.Size = new System.Drawing.Size(395, 30);
            this.comA3Soru1.TabIndex = 83;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Yu Gothic UI Semibold", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(8, 338);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 31);
            this.label19.TabIndex = 73;
            this.label19.Text = "4)";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Location = new System.Drawing.Point(50, 344);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(301, 32);
            this.label20.TabIndex = 70;
            this.label20.Text = "Yürüyüş yapmanın günlük ruh halinize iyi geldiğini \r\ndüşünüyor musunuz ?";
            // 
            // btnAnket3
            // 
            this.btnAnket3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAnket3.Location = new System.Drawing.Point(322, 433);
            this.btnAnket3.Name = "btnAnket3";
            this.btnAnket3.Size = new System.Drawing.Size(127, 41);
            this.btnAnket3.TabIndex = 24;
            this.btnAnket3.Text = "Kaydet";
            this.btnAnket3.UseVisualStyleBackColor = true;
            this.btnAnket3.Click += new System.EventHandler(this.btnAnket3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(-71, 61);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(610, 26);
            this.pictureBox2.TabIndex = 69;
            this.pictureBox2.TabStop = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.ForeColor = System.Drawing.Color.Red;
            this.label21.Location = new System.Drawing.Point(14, 90);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(33, 26);
            this.label21.TabIndex = 43;
            this.label21.Text = "1)";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(10, 259);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(33, 26);
            this.label22.TabIndex = 47;
            this.label22.Text = "3)";
            // 
            // lblYuruyus
            // 
            this.lblYuruyus.AutoSize = true;
            this.lblYuruyus.BackColor = System.Drawing.Color.Transparent;
            this.lblYuruyus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblYuruyus.Location = new System.Drawing.Point(127, 33);
            this.lblYuruyus.Name = "lblYuruyus";
            this.lblYuruyus.Size = new System.Drawing.Size(211, 25);
            this.lblYuruyus.TabIndex = 25;
            this.lblYuruyus.Text = "YÜRÜYÜŞ YAPMAK";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Location = new System.Drawing.Point(50, 267);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(298, 16);
            this.label24.TabIndex = 30;
            this.label24.Text = "Yürüyüş yaparken tek olmayı mı tercih edersiniz ?";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label25.ForeColor = System.Drawing.Color.Red;
            this.label25.Location = new System.Drawing.Point(10, 177);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(33, 26);
            this.label25.TabIndex = 45;
            this.label25.Text = "2)";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Location = new System.Drawing.Point(56, 181);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(331, 16);
            this.label26.TabIndex = 32;
            this.label26.Text = "Çevrenizde yürüyüş yapmak için uygun alanlar var mı ?";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Location = new System.Drawing.Point(54, 94);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(257, 16);
            this.label27.TabIndex = 28;
            this.label27.Text = "Günde kaç dakika yürüyüş yapıyorsunuz ?";
            // 
            // comA2Soru3
            // 
            this.comA2Soru3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comA2Soru3.FormattingEnabled = true;
            this.comA2Soru3.Items.AddRange(new object[] {
            "Korku",
            "Komedi",
            "Romantik",
            "Gerilim",
            "Polisiye ",
            "Macera",
            "Bilim kurgu"});
            this.comA2Soru3.Location = new System.Drawing.Point(38, 291);
            this.comA2Soru3.Name = "comA2Soru3";
            this.comA2Soru3.Size = new System.Drawing.Size(395, 30);
            this.comA2Soru3.TabIndex = 81;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Yu Gothic UI Semibold", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(13, 338);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 31);
            this.label9.TabIndex = 73;
            this.label9.Text = "4)";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.comSoru4);
            this.panel3.Controls.Add(this.comSoru3);
            this.panel3.Controls.Add(this.ComSoru2);
            this.panel3.Controls.Add(this.comSoru1);
            this.panel3.Controls.Add(this.pictureBox5);
            this.panel3.Controls.Add(this.lblSosyal);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.btnAnket1);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(7, 99);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(472, 507);
            this.panel3.TabIndex = 84;
            // 
            // comSoru4
            // 
            this.comSoru4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comSoru4.FormattingEnabled = true;
            this.comSoru4.Items.AddRange(new object[] {
            "Evet",
            "Hayır"});
            this.comSoru4.Location = new System.Drawing.Point(38, 385);
            this.comSoru4.Name = "comSoru4";
            this.comSoru4.Size = new System.Drawing.Size(395, 30);
            this.comSoru4.TabIndex = 78;
            // 
            // comSoru3
            // 
            this.comSoru3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comSoru3.FormattingEnabled = true;
            this.comSoru3.Items.AddRange(new object[] {
            "200+",
            "400+",
            "800+"});
            this.comSoru3.Location = new System.Drawing.Point(38, 291);
            this.comSoru3.Name = "comSoru3";
            this.comSoru3.Size = new System.Drawing.Size(395, 30);
            this.comSoru3.TabIndex = 77;
            // 
            // ComSoru2
            // 
            this.ComSoru2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ComSoru2.FormattingEnabled = true;
            this.ComSoru2.Items.AddRange(new object[] {
            "Sinemaya gitmek ",
            "Yürüyüş yapmak ",
            "Avm\'ye gitmek ",
            "Kulüplere gitmek ",
            "Eğlence mekanlarına gitmek "});
            this.ComSoru2.Location = new System.Drawing.Point(38, 211);
            this.ComSoru2.Name = "ComSoru2";
            this.ComSoru2.Size = new System.Drawing.Size(395, 30);
            this.ComSoru2.TabIndex = 76;
            // 
            // comSoru1
            // 
            this.comSoru1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comSoru1.FormattingEnabled = true;
            this.comSoru1.Items.AddRange(new object[] {
            "Evet",
            "Hayır"});
            this.comSoru1.Location = new System.Drawing.Point(38, 122);
            this.comSoru1.Name = "comSoru1";
            this.comSoru1.Size = new System.Drawing.Size(395, 30);
            this.comSoru1.TabIndex = 74;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(-75, 61);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(610, 26);
            this.pictureBox5.TabIndex = 75;
            this.pictureBox5.TabStop = false;
            // 
            // lblSosyal
            // 
            this.lblSosyal.AutoSize = true;
            this.lblSosyal.BackColor = System.Drawing.Color.Transparent;
            this.lblSosyal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSosyal.Location = new System.Drawing.Point(105, 33);
            this.lblSosyal.Name = "lblSosyal";
            this.lblSosyal.Size = new System.Drawing.Size(183, 25);
            this.lblSosyal.TabIndex = 25;
            this.lblSosyal.Text = "SOSYAL YAŞAM";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Yu Gothic UI Semibold", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(6, 338);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 31);
            this.label8.TabIndex = 49;
            this.label8.Text = "4)";
            // 
            // btnAnket1
            // 
            this.btnAnket1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAnket1.Location = new System.Drawing.Point(306, 433);
            this.btnAnket1.Name = "btnAnket1";
            this.btnAnket1.Size = new System.Drawing.Size(127, 41);
            this.btnAnket1.TabIndex = 24;
            this.btnAnket1.Text = "Kaydet";
            this.btnAnket1.UseVisualStyleBackColor = true;
            this.btnAnket1.Click += new System.EventHandler(this.btnAnket1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(14, 257);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 26);
            this.label7.TabIndex = 47;
            this.label7.Text = "3)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(14, 173);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 26);
            this.label6.TabIndex = 45;
            this.label6.Text = "2)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(14, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 26);
            this.label5.TabIndex = 43;
            this.label5.Text = "1)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(47, 350);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(378, 16);
            this.label2.TabIndex = 25;
            this.label2.Text = "Hayat standartlarınızı dilediğiniz gibi karşılayabiliyor musunuz ?";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(54, 265);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(277, 16);
            this.label4.TabIndex = 30;
            this.label4.Text = "Sosyal yaşamınız için ayırdığınız bütçe nedir ?";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(54, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(246, 16);
            this.label3.TabIndex = 28;
            this.label3.Text = "Günlük rutininizde dışarıya çıkar mısınız ?";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(54, 181);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(253, 16);
            this.label1.TabIndex = 32;
            this.label1.Text = "Tercih ettiğiniz sosyal aktiviteler nelerdir ?";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.comA2Soru4);
            this.panel2.Controls.Add(this.comA2Soru3);
            this.panel2.Controls.Add(this.comA2Soru2);
            this.panel2.Controls.Add(this.comA2Soru1);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.btnAnket2);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.lblSinema);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Location = new System.Drawing.Point(493, 99);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(472, 507);
            this.panel2.TabIndex = 85;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Location = new System.Drawing.Point(54, 350);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(310, 32);
            this.label15.TabIndex = 70;
            this.label15.Text = "Sinema sektörüne olan ilginin zamanla azalacağını \r\ndüşünüyor musunuz ? ";
            // 
            // btnAnket2
            // 
            this.btnAnket2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAnket2.Location = new System.Drawing.Point(306, 433);
            this.btnAnket2.Name = "btnAnket2";
            this.btnAnket2.Size = new System.Drawing.Size(127, 41);
            this.btnAnket2.TabIndex = 24;
            this.btnAnket2.Text = "Kaydet";
            this.btnAnket2.UseVisualStyleBackColor = true;
            this.btnAnket2.Click += new System.EventHandler(this.btnAnket2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(-71, 61);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(610, 26);
            this.pictureBox1.TabIndex = 69;
            this.pictureBox1.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(14, 90);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(33, 26);
            this.label12.TabIndex = 43;
            this.label12.Text = "1)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(14, 257);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(33, 26);
            this.label10.TabIndex = 47;
            this.label10.Text = "3)";
            // 
            // lblSinema
            // 
            this.lblSinema.AutoSize = true;
            this.lblSinema.BackColor = System.Drawing.Color.Transparent;
            this.lblSinema.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSinema.Location = new System.Drawing.Point(182, 33);
            this.lblSinema.Name = "lblSinema";
            this.lblSinema.Size = new System.Drawing.Size(95, 25);
            this.lblSinema.TabIndex = 25;
            this.lblSinema.Text = "SİNEMA";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Location = new System.Drawing.Point(54, 265);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(200, 16);
            this.label16.TabIndex = 30;
            this.label16.Text = "En çok tercih ettiğiniz tür hangisi?";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(14, 175);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 26);
            this.label11.TabIndex = 45;
            this.label11.Text = "2)";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Location = new System.Drawing.Point(54, 183);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(327, 16);
            this.label18.TabIndex = 32;
            this.label18.Text = "Sinema biletlerinin fiyatlarını normal buluyor musunuz ?";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Location = new System.Drawing.Point(54, 94);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(244, 16);
            this.label17.TabIndex = 28;
            this.label17.Text = "Ayda kaç kere sinemaya gidiyorsunuz ?";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MidnightBlue;
            this.panel1.BackgroundImage = global::Anket_Otomasyon.Properties.Resources.pngwing_com__29_;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnAnketAnalizi);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Location = new System.Drawing.Point(2, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1451, 80);
            this.panel1.TabIndex = 83;
            // 
            // btnAnketAnalizi
            // 
            this.btnAnketAnalizi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAnketAnalizi.BackgroundImage")));
            this.btnAnketAnalizi.Location = new System.Drawing.Point(1306, 3);
            this.btnAnketAnalizi.Name = "btnAnketAnalizi";
            this.btnAnketAnalizi.Size = new System.Drawing.Size(144, 72);
            this.btnAnketAnalizi.TabIndex = 77;
            this.btnAnketAnalizi.Text = "Anket Analizi";
            this.btnAnketAnalizi.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(199, 80);
            this.pictureBox3.TabIndex = 75;
            this.pictureBox3.TabStop = false;
            // 
            // frmSosyal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1460, 611);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Location = new System.Drawing.Point(30, 70);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSosyal";
            this.Text = "Sosyal Anket";
            this.Load += new System.EventHandler(this.frmSosyal_Load);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comA2Soru4;
        private System.Windows.Forms.ComboBox comA2Soru2;
        private System.Windows.Forms.ComboBox comA2Soru1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox comA3Soru4;
        private System.Windows.Forms.ComboBox comA3Soru3;
        private System.Windows.Forms.ComboBox comA3Soru2;
        private System.Windows.Forms.ComboBox comA3Soru1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnAnket3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblYuruyus;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox comA2Soru3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox comSoru4;
        private System.Windows.Forms.ComboBox comSoru3;
        private System.Windows.Forms.ComboBox ComSoru2;
        private System.Windows.Forms.ComboBox comSoru1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label lblSosyal;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnAnket1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnAnket2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblSinema;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnAnketAnalizi;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}